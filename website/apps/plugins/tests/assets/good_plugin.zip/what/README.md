# Datetime

Returns whether the current date or time


### commands

Name | Action
------------ | -------------
date() | Returns the current date
time() | Returns the current time
